/**
 
 *
 * THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
 * PARTICULAR PURPOSE.
 */

#pragma once

#include "Registers.hpp"
#include <platform/interfaces/access/II2c.hpp>


using RegType = uint8_t;


class RegistersI2c8Bit :
    public Registers<RegType>
{
public:
    RegistersI2c8Bit(uint8_t devAddr, II2c *access);
    virtual ~RegistersI2c8Bit() = default;

    inline RegType readRegister(RegType regAddr)
    {
        RegType value;
        readRegister(regAddr, value);
        return value;
    }

    // IRegisters
    sr_t readRegister(RegType regAddr, RegType &value) override;
    sr_t writeRegister(RegType regAddr, RegType value) override;

    sr_t readRegisterBurst(RegType regAddr, RegType values[], RegType count) override;
    sr_t writeRegisterBurst(RegType regAddr, const RegType values[], RegType count) override;

private:
    const uint8_t m_devAddr;
    II2c *m_access;
};
