#include "impl/Platform.hpp"


Platform platform;


//IGpio* defaultIGpio = platform.getIGpio();
//II2c* defaultII2c = platform.getII2c();;
//ISpi* defaultISpi = platform.getISpi();;
//IAdc* defaultIAdc = platform.getIAdc();

IGpio* defaultIGpio = &platform.m_gpio;
II2c* defaultII2c =   &platform.m_i2c;;
ISpi* defaultISpi =   &platform.m_spi;
IAdc* defaultIAdc =   &platform.m_adc;


#include "impl/ArduinoDac.hpp"
ArduinoDac Dac;
IDac *defaultIDac = &Dac;
