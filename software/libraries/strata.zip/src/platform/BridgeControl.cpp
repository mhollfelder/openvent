/**
 
 *
 * THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
 * PARTICULAR PURPOSE.
 */

#include "BridgeControl.hpp"


void BridgeControl::setDefaultTimeout()
{
}

IAdc *BridgeControl::getIAdc()
{
    return nullptr;
}

IGpio *BridgeControl::getIGpio()
{
    return nullptr;
}

II2c *BridgeControl::getII2c()
{
    return nullptr;
}

ISpi *BridgeControl::getISpi()
{
    return nullptr;
}

IFlash *BridgeControl::getIFlash()
{
    return nullptr;
}

IMemory *BridgeControl::getIMemory()
{
    return nullptr;
}
