/**
 
 *
 * THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
 * PARTICULAR PURPOSE.
 */

#include "ArduinoI2c.hpp"

#include <platform/exception/EPlatform.hpp>

#include <Wire.h>


ArduinoI2c::ArduinoI2c(int busId) :
	m_wire {(busId == 1) ? Wire1 : Wire}
{	
//	m_wire.begin();
}

ArduinoI2c::~ArduinoI2c()
{
}

uint16_t ArduinoI2c::getI2cMaxTransfer()
{
    return UINT16_MAX;
}

sr_t ArduinoI2c::i2cRead(uint8_t devAddr, uint16_t length, uint8_t buffer[])
{
	m_wire.requestFrom(static_cast<int>(devAddr), length, 1);
	while (m_wire.available())
	{
		*buffer++ = m_wire.read();
		length--;
	}
	if (length)
	{
		RET_THROW EPlatform("I2C not enough bytes returned");
	}
	RETURN
}

sr_t ArduinoI2c::readI2cNoRegister(uint8_t devAddr, uint16_t length, uint8_t buffer[])
{
	THROWS(i2cRead(devAddr, length, buffer);)
	RETURN
}

sr_t ArduinoI2c::readI2c8BitRegister(uint8_t devAddr, uint8_t regAddr, uint16_t length, uint8_t buffer[])
{
	m_wire.beginTransmission(devAddr);
	m_wire.write(regAddr);
	m_wire.endTransmission();

	THROWS(i2cRead(devAddr, length, buffer);)
	RETURN
}

sr_t ArduinoI2c::readI2c16BitRegister(uint8_t devAddr, uint16_t regAddr, uint16_t length, uint8_t buffer[])
{
	m_wire.beginTransmission(devAddr);
	m_wire.write(regAddr >> 8);
	m_wire.write(regAddr & 0xFF);
	m_wire.endTransmission();

	THROWS(i2cRead(devAddr, length, buffer);)
	RETURN
}

sr_t ArduinoI2c::writeI2cNoRegister(uint8_t devAddr, uint16_t length,
        const uint8_t buffer[])
{
	m_wire.beginTransmission(devAddr);
	while (length--)
	{
		m_wire.write(*buffer++);
	}
	m_wire.endTransmission();
	
	RETURN
}

sr_t ArduinoI2c::writeI2c8BitRegister(uint8_t devAddr, uint8_t regAddr,
        uint16_t length, const uint8_t buffer[])
{
	m_wire.beginTransmission(devAddr);
	m_wire.write(regAddr);
	while (length--)
	{
		m_wire.write(*buffer++);
	}
	m_wire.endTransmission();
	
	RETURN
}

sr_t ArduinoI2c::writeI2c16BitRegister(uint8_t devAddr, uint16_t regAddr,
        uint16_t length, const uint8_t buffer[])
{
	m_wire.beginTransmission(devAddr);
	m_wire.write(regAddr >> 8);
	m_wire.write(regAddr & 0xFF);
	while (length--)
	{
		m_wire.write(*buffer++);
	}
	m_wire.endTransmission();
	
	RETURN
}

sr_t ArduinoI2c::setI2cBusSpeed(uint32_t speed)
{	
	RETURN
}
