/**
 
 *
 * THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
 * PARTICULAR PURPOSE.
 */

#pragma once


template <unsigned int bits, typename IntType = int, typename RawType>
inline IntType getTwosComplement(RawType rawValue)
{
    if (rawValue & (static_cast<RawType>(1) << (bits - 1)))
    {
        return rawValue - (static_cast<IntType>(1) << bits);
    }
	else
	{
		return static_cast<IntType>(rawValue);
	}
}
