/**
 
 *
 * THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
 * PARTICULAR PURPOSE.
 */

#pragma once


template <unsigned int bits, typename IntType = unsigned int>
inline IntType getTwosComplement(IntType rawValue)
{
    if (rawValue & (1u << (bits - 1)))
    {
        rawValue -= static_cast<IntType>(1u << bits);
    }
    return rawValue;
}

